package movieapp.database;

import java.sql.*;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellDataFeatures;
import javafx.scene.control.TableView;
import javafx.util.Callback;

/**
 *
 * @author Mohammed Siad
 */
public class Database {

    private static Database instance = null;
    //Declare JDBC Driver
    private static final String JDBC_DRIVER = "oracle.jdbc.driver.OracleDriver";
    //Connection
    private Connection conn = null;

    //enter the correct local host ip address for your local database
    private final String host = "jdbc:oracle:thin:@<local host ip address>:1521:xe";
    private final String userName = "system";
    //enter the correct password
    private final String passwrd = "*******";

    private Database() {

    }

    public static Database getInstance() {
        if (instance == null) {
            instance = new Database();
        }
        return instance;
    }

    public Connection getConn() {
        if (conn == null) {
            getConnection();
        }
        return conn;
    }

    public void closeConn() {
        try {
            if (conn != null) {
                conn.close();
            }
        } catch (SQLException ex) {
            Logger.getLogger(Database.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void getConnection() {
        try {
            Class.forName(JDBC_DRIVER);
        } catch (ClassNotFoundException x) {
            System.out.println("Driver could not be loaded");
        }
        System.out.println("Oracle JDBC Driver Registered!");
        try {
            conn = DriverManager.getConnection(host, userName, passwrd);
        } catch (SQLException e) {
            System.out.println("Connection Failed! Check output console");
        }
        System.out.println("Connection success!");

    }

    public void createTables() {

        Statement s;
        String Customer, Movie, PurchaseOrder, Feedback;
        String WebsiteManager, OnlineStore, Inventory;
        Customer = "CREATE TABLE Customer(\n"
                + "		CustomerID INTEGER PRIMARY KEY NOT NULL,\n"
                + "		Username VARCHAR(25) UNIQUE NOT NULL,\n"
                + "		Email VARCHAR(30) NOT NULL,\n"
                + "		Address VARCHAR(30) NOT NULL,\n"
                + "		Password VARCHAR(25) NOT NULL,\n"
                + "		AreaCode INTEGER CHECK(AreaCode BETWEEN 100 AND 999),\n"
                + "		PhoneNo INTEGER CHECK(PhoneNo BETWEEN 1000000 AND 9999999)\n"
                + "		)";
        Movie = "CREATE TABLE Movie(\n"
                + "		MovieName VARCHAR(25) PRIMARY KEY NOT NULL,\n"
                + "		Publisher VARCHAR(25) NOT NULL,\n"
                + "		Genre VARCHAR(30) NOT NULL,\n"
                + "		Rating NUMBER CHECK(Rating BETWEEN 0 AND 5),\n"
                + "		Price Number\n"
                + "		)";
        PurchaseOrder = "CREATE TABLE PurchaseOrder(\n"
                + "		OrderID INTEGER PRIMARY KEY NOT NULL,\n"
                + "		CustomerID REFERENCES Customer(CustomerID) ON DELETE CASCADE,\n"
                + "		Quantity INTEGER NOT NULL,\n"
                + "		MovieName VARCHAR (25) REFERENCES Movie(MovieName) ON DELETE CASCADE,\n"
                + "		OrderDate VARCHAR(25) NOT NULL\n"
                + "		)";
        Feedback = "CREATE TABLE Feedback(\n"
                + "		FeedbackID INTEGER PRIMARY KEY NOT NULL,\n"
                + "		CustomerID REFERENCES Customer(CustomerID) ON DELETE CASCADE,\n"
                + "		MovieName VARCHAR(25) REFERENCES Movie(MovieName) ON DELETE CASCADE,\n"
                + "		CRating NUMBER CHECK(CRating BETWEEN 0 AND 5),\n"
                + "		Review VARCHAR(150)\n"
                + "		)";
        WebsiteManager = "CREATE TABLE WebsiteManager(\n"
                + "		AdminEmail VARCHAR(50) PRIMARY KEY NOT NULL,\n"
                + "		AdminPassword VARCHAR(25) NOT NULL,\n"
                + "		AdminName VARCHAR(25) NOT NULL,\n"
                + "		AdminPhoneNo INTEGER CHECK(AdminPhoneNo BETWEEN 1000000000 AND 9999999999) UNIQUE\n"
                + "		)";
        OnlineStore = "CREATE TABLE OnlineStore(\n"
                + "		StoreID INTEGER PRIMARY KEY NOT NULL,\n"
                + "		URL VARCHAR(50) NOT NULL,\n"
                + "		StoreName VARCHAR(25) NOT NULL,\n"
                + "		SupportNo INTEGER REFERENCES WebsiteManager(AdminPhoneNo) ON DELETE CASCADE\n"
                + "		)";
        Inventory = "CREATE TABLE Inventory(\n"
                + "		MovieName VARCHAR(25) REFERENCES Movie(MovieName) ON DELETE CASCADE PRIMARY KEY,\n"
                + "		Stock INTEGER NOT NULL,\n"
                + "		ShippingWeight NUMBER NOT NULL\n"
                + "		)";
        try {
            s = getConn().createStatement();
            s.executeUpdate(Customer);
            s.executeUpdate(Movie);
            s.executeUpdate(PurchaseOrder);
            s.executeUpdate(Feedback);
            s.executeUpdate(WebsiteManager);
            s.executeUpdate(OnlineStore);
            s.executeUpdate(Inventory);
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    public void populateTables() {
        String s1, s2, s3, s4, s5;
        //Customer
        s1 = "INSERT INTO Customer VALUES\n"
                + "(342,'MathewKing','Mat@gmail.com','76 Courtland St.','Password', 333, 4066174)";
        s2 = "INSERT INTO Customer VALUES\n"
                + "(343,'RickBob','Ricky@gmail.com','693 Water St.','Password', 313, 7566378)";
        s3 = "INSERT INTO Customer VALUES\n"
                + "(346,'EmilyJin','Emma@gmail.com','428 E. Warren St.','Password', 813, 8236375)";
        s4 = "INSERT INTO Customer VALUES\n"
                + "(347,'JadaLu','Jade@gmail.com','7695 East Cherry Hill Ave.','Password', 413, 2536368)";
        s5 = "INSERT INTO Customer VALUES\n"
                + "(348,'JonnyDebt','jon@gmail.com','7685 West Rockaway Road','Password', 713, 6516301)";
        String[] list = {s1, s2, s3, s4, s5};
        executeList(list);
        //Movie
        s1 = "INSERT INTO Movie VALUES('Schindlers List','Universal Studios','DRAMA', 5, 11.99)";
        s2 = "INSERT INTO Movie VALUES('Terminator 2','Carolco Pictures','ACTION', 5, 11.99)";
        s3 = "INSERT INTO Movie VALUES('Pulp Fiction','Miramax','DRAMA', 5, 11.99)";
        s4 = "INSERT INTO Movie VALUES('Memento','Newmarket Films','MYSTERY', 5, 11.99)";
        s5 = "INSERT INTO Movie VALUES('Letters to Juliet','Summit Entertainment','ROMANCE', 5, 8.99)";
        String[] list2 = {s1, s2, s3, s4, s5};
        executeList(list2);
        //PurchaseOrder
        s1 = "INSERT INTO PurchaseOrder VALUES(932,342,1,'Pulp Fiction','120322')";
        s2 = "INSERT INTO PurchaseOrder VALUES(937,343,3,'Memento','300822')";
        s3 = "INSERT INTO PurchaseOrder VALUES(956,346,2,'Schindlers List','240222')";
        s4 = "INSERT INTO PurchaseOrder VALUES(930,347,4,'Letters to Juliet','040822')";
        s5 = "INSERT INTO PurchaseOrder VALUES(904,348,1,'Terminator 2','201122')";
        String[] list3 = {s1, s2, s3, s4, s5};
        executeList(list3);

        //Feedback
        s1 = "INSERT INTO Feedback VALUES (100, 342,'Pulp Fiction', 1,'It was bad')";
        s2 = "INSERT INTO Feedback VALUES (101, 343,'Memento', 1,'It sucks')";
        s3 = "INSERT INTO Feedback VALUES (103, 346,'Terminator 2', 5,'I loved it')";
        s4 = "INSERT INTO Feedback VALUES (102, 347,'Letters to Juliet', 5,'goat movie')";
        s5 = "INSERT INTO Feedback VALUES (104, 348,'Schindlers List', 2.5,'its average')";
        String[] list4 = {s1, s2, s3, s4, s5};
        executeList(list4);

        //WebsiteManager
        s1 = "INSERT INTO WebsiteManager VALUES\n"
                + "('James@gmail.com', 'AdminPassword','Kevin Butler', 4168929872)";
        String[] list5 = {s1};
        executeList(list5);

        //OnlineStore
        s1 = "INSERT INTO OnlineStore VALUES(888,'https://harrysmoviestore.ca', 'Harrys Movie Store', 4168929872)";
        String[] list6 = {s1};
        executeList(list6);

        //Inventory
        s1 = "INSERT INTO Inventory VALUES ('Pulp Fiction', 4, 3.1)";
        s2 = "INSERT INTO Inventory VALUES ('Memento', 2, 3.3)";
        s3 = "INSERT INTO Inventory VALUES ('Schindlers List', 5, 4.2)";
        s4 = "INSERT INTO Inventory VALUES ('Letters to Juliet', 10, 2.1)";
        s5 = "INSERT INTO Inventory VALUES ('Terminator 2', 10, 1.3)";
        String[] list7 = {s1, s2, s3, s4, s5};
        executeList(list7);

    }

    private void executeList(String[] list) {
        Statement s;
        try {
            s = getConn().createStatement();
            for (String query : list) {
                s.executeUpdate(query);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

    }

    /*
    create a SQL string
    create prepared statement
    execute statement
    returns Result set
     */
    public TableView executeQuery(String tableName, String colName, String colValue) {
        String sql = "SELECT* FROM " + tableName + " WHERE " + colName + " = " + colValue;
        TableView tv = makeTable(sql);
        return tv;
    }

    public void dropTables() {
        String query;
        Statement s = null;
        String dropTable = "DROP TABLE ";
        getConnection();
        String[] list = {"Inventory", "OnlineStore", "WebsiteManager", "Feedback", "PurchaseOrder", "Movie", "Customer"};
        for (String str : list) {
            query = dropTable.concat(str);
            try {
                s = getConn().createStatement();
                s.executeUpdate(query);
            } catch (SQLException ex) {
                Logger.getLogger(Database.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    public TableView makeTable(String SQL) {
        TableView tableview = new TableView();
        ObservableList<ObservableList> data = FXCollections.observableArrayList();
        try {
            ResultSet rs = getConn().createStatement().executeQuery(SQL);
            
            for (int i = 0; i < rs.getMetaData().getColumnCount(); i++) {
                //We are using non property style for making dynamic table
                final int j = i;
                TableColumn col = new TableColumn(rs.getMetaData().getColumnName(i + 1));
                col.setCellValueFactory(new Callback<CellDataFeatures<ObservableList, String>, ObservableValue<String>>() {
                    @Override
                    public ObservableValue<String> call(CellDataFeatures<ObservableList, String> param) {
                        return new SimpleStringProperty(param.getValue().get(j).toString());
                    }
                });

                tableview.getColumns().addAll(col);
            }

            while (rs.next()) {
                //Iterate Row
                ObservableList<String> row = FXCollections.observableArrayList();
                for (int i = 1; i <= rs.getMetaData().getColumnCount(); i++) {
                    //Iterate Column
                    row.add(rs.getString(i));
                }
                data.add(row);

            }

            //FINALLY ADDED TO TableView
            tableview.setItems(data);
        } catch (SQLException e) {
            System.out.println("Error on Building Data");
        }
        return tableview;
    }

    //insertion
    public void insert(String table, ArrayList<String> values) {
        String sql;
        if (table.equalsIgnoreCase("Customer")) {
            sql = ("INSERT INTO Customer VALUES\n"
                    + "(" + values.get(0) + ",'" + values.get(1) + "','" + values.get(2) + "','" + values.get(3) + "','" + values.get(4) + "', " + values.get(5) + "," + values.get(6) + ")");
        } else if (table.equalsIgnoreCase("Movie")) {
            sql = ("INSERT INTO Movie VALUES('" + values.get(0) + "','" + values.get(1) + "','" + values.get(2) + "', " + values.get(3) + ", " + values.get(4) + ")");
        } else if (table.equalsIgnoreCase("PurchaseOrder")) {
            sql = ("INSERT INTO PurchaseOrder VALUES(" + values.get(0) + "," + values.get(1) + "," + values.get(2) + ",'" + values.get(3) + "','" + values.get(4) + "')");
        } else if (table.equalsIgnoreCase("Feedback")) {
            sql = ("INSERT INTO Feedback VALUES (" + values.get(0) + ", " + values.get(1) + ",'" + values.get(2) + "', " + values.get(3) + ",'" + values.get(4) + "')");
        } else if (table.equalsIgnoreCase("inventory")) {
            sql = ("INSERT INTO Inventory VALUES ('" + values.get(0) + "', " + values.get(1) + ", " + values.get(2) + ")");
        } else {
            sql = "";
            System.out.println("Error insertion attempt failed");
        }
        
        String[] list = {sql};
        if (!sql.equals("")) {
            executeList(list);
        }
    }

    public void delete(String table, String PK) {
        String sql;

        if (table.equalsIgnoreCase("Customer")) {
            sql = "DELETE FROM " + table + " WHERE CustomerID = " + PK;
        } else if (table.equalsIgnoreCase("Movie")) {
            sql = "DELETE FROM " + table + " WHERE MovieName = '" + PK + "'";
        } else if (table.equalsIgnoreCase("PurchaseOrder")) {
            sql = "DELETE FROM " + table + " WHERE OrderID = " + PK;
        } else if (table.equalsIgnoreCase("Feedback")) {
            sql = "DELETE FROM " + table + " WHERE FeedbackID = " + PK;
        } else if (table.equalsIgnoreCase("Inventory")) {
            sql = "DELETE FROM " + table + " WHERE MovieName = '" + PK + "'";
        } else {
            sql = null;
            System.out.println("Error deletion attempt failed");
        }
        String[] list = {sql};
        if (sql != null) {
            executeList(list);
        }
    }

}
