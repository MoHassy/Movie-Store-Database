package movieapp;

import java.util.ArrayList;
import movieapp.database.*;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

/**
 *
 * @author Mohammed Siad
 */
public class MovieApp extends Application {

    /*
            DATABASE MANAGER
     */
    Database database = Database.getInstance();

    /*
    *       SCENES
     */
    @Override
    public void start(Stage primaryStage) {
        //Nodes 
        Label Welcome = new Label("Welcome To The Movie Database App");
        Welcome.getStyleClass().add("title");
        Label Email = new Label("Username: ");
        Label Password = new Label("Password: ");
        TextField UsernameTxt = new TextField();
        PasswordField PasswordTxt = new PasswordField();
        Button btn = new Button();

        //Login button 
        btn.setText("Login");

        /**
         * Setup of login scene
         */
        // panes
        FlowPane pane = new FlowPane();
        VBox vbox = new VBox(10);
        HBox hbox = new HBox(10);
        VBox vbox1 = new VBox(25);
        VBox vbox2 = new VBox(20);

        //add labels and textfields to vbox1
        vbox1.getChildren().add(Email);
        vbox1.getChildren().add(Password);

        //add labels, textfield and bottons to vbox2
        vbox2.getChildren().add(UsernameTxt);
        vbox2.getChildren().add(PasswordTxt);
        vbox2.getChildren().add(btn);

        //add vboxes to hbox
        hbox.getChildren().add(vbox1);
        hbox.getChildren().add(vbox2);

        //add welcome to vbox
        vbox.getChildren().add(Welcome);
        //add hbox to vbox
        vbox.getChildren().add(hbox);
        //add vbox to pane
        pane.getChildren().add(vbox);
        pane.setAlignment(Pos.CENTER);

        //setup Scene
        Scene loginScene = new Scene(pane, 500, 250);
        loginScene.getStylesheets().add("style/stylesheet.css");
        primaryStage.setTitle("Movie App");
        primaryStage.setScene(loginScene);
        primaryStage.centerOnScreen();
        primaryStage.show();

        /**
         * Event Handlers
         */
        String AdEmail = "admin";
        String AdPass = "admin";
        btn.setOnAction((ActionEvent event) -> {
            boolean login;
            login = (UsernameTxt.getText().equalsIgnoreCase(AdEmail) && PasswordTxt.getText().equals(AdPass));
            if (login) {
                System.out.println("Login Successful!");
                tables(primaryStage);
            } else {
                PasswordTxt.clear();
            }
        });
        //enter on password field
        PasswordTxt.setOnAction((ActionEvent event) -> btn.fire());
        UsernameTxt.setOnAction((ActionEvent event) -> btn.fire());

        //close connection when window is closed
        primaryStage.setOnCloseRequest((WindowEvent e) -> {
            if (database != null) {
                database.closeConn();
            }
        });
    }

    public void tables(Stage primaryStage) {
        ArrayList<TableView> tableviews = null;
        tableviews = new ArrayList();
        String[] tablenames = {"Customer", "Movie", "PurchaseOrder", "Feedback",
                                "Inventory", "WebsiteManager", "OnlineStore"};
        String[] queries = {"SELECT* FROM Customer", "SELECT* FROM Movie",
                            "SELECT* FROM PurchaseOrder", "SELECT* FROM Feedback", 
                            "SELECT* FROM Inventory","SELECT* FROM WebsiteManager",
                            "SELECT* FROM OnlineStore"};
        ArrayList<Label> tables = new ArrayList();
        
        for(String sql : queries){
            TableView tv = database.makeTable(sql);
            tv.columnResizePolicyProperty();
            tv.setPrefWidth(700);
            tv.setPrefHeight(160);
            tableviews.add(tv);
            
        }
        
        for(String name : tablenames){
            tables.add(new Label(name));
        }
        
        HBox hbox = new HBox(); 
        VBox vbox1 = new VBox();
        vbox1.setSpacing(5);
        VBox vbox2 = new VBox();
        vbox2.setSpacing(5);
        for(int i= 0; i <= tables.size()/2; i++){
            vbox1.getChildren().addAll(tables.get(i),tableviews.get(i));
        }
        for(int i = tables.size()/2 + 1; i < tables.size(); i++){
            vbox2.getChildren().addAll(tables.get(i),tableviews.get(i));
        }
        
        vbox1.setPadding(new Insets(5, 5, 5, 5));
        vbox2.setPadding(new Insets(5, 5, 5, 5));
        
        hbox.getChildren().addAll(vbox1, vbox2);
        hbox.setPadding(new Insets(5, 5, 5, 5));
        
        FlowPane flowPane = new FlowPane();
        flowPane.getChildren().add(hbox);
        flowPane.setAlignment(Pos.TOP_CENTER);

        //buttons
        Button create = new Button("Create Tables");
        create.setPrefWidth(200);
        create.setPadding(new Insets(10, 10, 10, 10));
        
        Button populate = new Button("Populate Tables");
        populate.setPrefWidth(200);
        populate.setPadding(new Insets(10, 10, 10, 10));
        
        Button drop = new Button("Drop Tables");
        drop.setPrefWidth(200);
        drop.setPadding(new Insets(10, 10, 10, 10));
        
        
        HBox hbox2 = new HBox();
        hbox2.setSpacing(10);
        hbox2.setAlignment(Pos.CENTER);
        hbox2.getChildren().addAll(create, populate, drop);
        
        HBox dummyHbox = new HBox();
        dummyHbox.setMinHeight(100);
        vbox2.getChildren().addAll(dummyHbox, hbox2);
        
        //panes for text fields and insertion / deletion button
        HBox hbox3 = new HBox();
        HBox hbox4 = new HBox();
        hbox4.setSpacing(50);
        hbox4.setPadding(new Insets(10, 10, 10, 10));
        //Dummy Hbox2
        
        HBox dummyHbox2 = new HBox();
        
        dummyHbox2.setMinHeight(30);
        
        VBox vbox4 = new VBox();
        vbox4.setSpacing(10);
        vbox4.getChildren().addAll(dummyHbox2, hbox3, hbox4);
        
        
        //insertion and deletion section
        //7 text boxes alligned horizontally 
        ArrayList<TextField> textfields = new ArrayList();
        TextField tabletxt = new TextField();
        tabletxt.setPromptText("Table Name");
        hbox3.getChildren().add(tabletxt);
        for(int i = 0; i < 7; i++){
            int n = i + 1;
            TextField col = new TextField();
            col.setPromptText("Attribute: " + n);
            hbox3.getChildren().add(col);
            textfields.add(col);
        }
        hbox3.setSpacing(5);
        hbox3.setAlignment(Pos.CENTER);
        
        Button insert = new Button("Insert");
        insert.setPrefWidth(200);
        insert.setPadding(new Insets(10, 10, 10, 10));
        hbox4.getChildren().add(insert);
        Button delete = new Button("Delete");
        delete.setPrefWidth(200);
        delete.setPadding(new Insets(10, 10, 10, 10));
        hbox4.getChildren().add(delete);
        hbox4.setSpacing(5);
        hbox4.setAlignment(Pos.CENTER);
        
        Button logout = new Button("Log Out");
        logout.setPrefWidth(200);
        logout.setPadding(new Insets(10, 10, 10, 10));
        HBox hbox5 = new HBox();
        hbox5.getChildren().add(logout);
        hbox5.setSpacing(10);
        hbox5.setAlignment(Pos.CENTER);
        
        VBox vboxFinal = new VBox();
        vboxFinal.getChildren().addAll(flowPane, vbox4, hbox5);
        
        Scene scene = new Scene(vboxFinal, 1450, 1000);
        scene.getStylesheets().add("/style/stylesheet.css");
        primaryStage.setTitle("Tables");
        primaryStage.setScene(scene);
        primaryStage.centerOnScreen();
        
        //even handlers
        create.setOnAction((ActionEvent e) ->{
            database.createTables();
            tables(primaryStage);
        });
        
        populate.setOnAction((ActionEvent e) ->{
            database.populateTables();
            tables(primaryStage);
        });
        drop.setOnAction((ActionEvent e) ->{
            database.dropTables();
            tables(primaryStage);
        });
        
        insert.setOnAction((ActionEvent e) ->{
            String table = tabletxt.getText();
            ArrayList<String> stringList = new ArrayList();
            for(int i = 0; i < 7; i++){
                stringList.add(textfields.get(i).getText());
            }
            database.insert(table, stringList);
            tables(primaryStage);
        });
        
        delete.setOnAction((ActionEvent e) ->{
            String table = tabletxt.getText();
            database.delete(table, textfields.get(0).getText());
            tables(primaryStage);
        });
        
        logout.setOnAction((ActionEvent e)->{
            if (database != null) {
                    database.closeConn();
                }
            primaryStage.close();
        });
        

    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

}
